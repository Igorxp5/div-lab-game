def gameController(game):
	game.createRoom('Sala de Teste', 3, 'Eu')
	# print(game.getAvailableRooms())
	# game.joinRoomToPlay(list(game.getAvailableRooms().keys())[0], 'Eu')
	# game.joinRoomToWatch(list(game.getAvailableRooms().keys())[0], 'Outro')
	# game.kickPlayerFromRoom(game.getCurrentRoom().getPlayers()[1])
	# game.quitRoom()
	# game.startGame()
	# game.voteRoundMaster(game.getCurrentRoom().getPlayers()[0])
	# game.chooseRoundWord('bola', 'bo-la')
	# game.answerRoundWord('bo-la-la')
	# game.contestCorrectAnswer()
	# contestingWord = game.getContestingWord()
	# roundMasterWord = game.getRoundWord()
	# noneWord = None
	# game.voteCorrectAnswer(roundMasterWord)
	pass
